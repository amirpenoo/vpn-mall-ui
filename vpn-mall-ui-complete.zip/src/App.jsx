export default function App() {
  return <h1 style={{ textAlign: "center", marginTop: 100 }}>VPN Mall UI آماده است!</h1>;
}